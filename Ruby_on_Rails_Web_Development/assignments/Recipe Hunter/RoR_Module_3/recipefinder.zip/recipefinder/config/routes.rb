Rails.application.routes.draw do

  root 'recipes#index'

end
